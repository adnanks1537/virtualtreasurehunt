$(document).ready(function () {
    const pinInput = $("#pin");
    const unlockButton = $("#unlockButton");
    const hintButton = $("#hintButton");
    const messageBox = $("#messageBox");

    // Event listener for unlock button
    unlockButton.click(function () {
        const enteredPin = pinInput.val();
        if (enteredPin === "2012") {
            window.location.href = "ai.html";
        } else {
            messageBox.text("Wrong PIN! Try again.");
            pinInput.val("");
        }
    });

    // Event listener for hint button
    hintButton.click(function () {
        messageBox.text("Hint: I am a four-digit number. My thousands digit is half of my hundreds digit, and my tens digit is twice my ones digit. What number am I?");
    });
});
