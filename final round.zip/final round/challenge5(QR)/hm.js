function checkMessage() {
    const inputMessage = document.getElementById('input-message').value.toLowerCase();
    const decodedMessage = 'FLAG{WELDONE_YOU_HAVE_DECODED}'; // Replace with the correct decoded message.

    if (inputMessage === decodedMessage) {
        document.getElementById('next-level').style.display = 'block';
    } else {
        alert('Incorrect message. Try again!');
    }
}

function showHint() {
    const hintElement = document.getElementById('hint');
    hintElement.style.display = 'block';
}

function goToNextLevel() {
    window.location.href = 'congrats.html';
}
