import os

# Create a directory to store the text files
if not os.path.exists("text_files"):
    os.makedirs("text_files")

# Create 100 text files with different content
for i in range(1, 101):
    filename = f"text_files/file_{i}.txt"
    content = f"This is text file {i} content."
    
    with open(filename, "w") as file:
        file.write(content)

print("100 text files have been created.")
