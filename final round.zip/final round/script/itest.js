$(document).ready(function () {
    const pinInput = $("#pin");
    const unlockButton = $("#unlockButton");
    const hintButton = $("#hintButton");
    const messageBox = $("#messageBox");

    // Event listener for unlock button
    unlockButton.click(function () {
        const enteredPin = pinInput.val();
        if (enteredPin === "2017") {
            window.location.href = "index.html";
        } else {
            messageBox.text("Wrong PIN! Try again.");
            pinInput.val("");
        }
    });

    // Event listener for hint button
    hintButton.click(function () {
        messageBox.text("Hint: The PIN is your birth year.");
    });
});
