const brailleMessage = "⠠⠁⠙⠝⠁⠝";
        const decodedMessage = "adnan"; // Correct decoded message for the next level.
        const nextPageURL = "sudoko.html";

        document.getElementById("decodedMessage").textContent = "";

        document.getElementById("submitBtn").addEventListener("click", function() {
            const userInput = document.getElementById("userInput").value.trim().toLowerCase();
            if (userInput === decodedMessage) {
                document.getElementById("decodedMessage").textContent = "Correct!";
                document.getElementById("nextLevelButton").style.display = "block";
                document.getElementById("hintButton").style.display = "none";
            } else {
                document.getElementById("decodedMessage").textContent = "Incorrect! Try again.";
            }
        });

        function showHint() {
            const hintModal = document.getElementById("hintModal");
            hintModal.style.display = "block";
        }

        // Close the hint modal when clicking outside the image
        window.onclick = function(event) {
            const hintModal = document.getElementById("hintModal");
            if (event.target == hintModal) {
                hintModal.style.display = "none";
            }
        }

        function goToNextLevel() {
            window.location.href = nextPageURL;
        }
    </script>
    <script>
        window.addEventListener('contextmenu', function (e) {
          e.preventDefault();
        });
        </script>
   