const pinForm = document.getElementById("pinForm");
const hintButton = document.getElementById("hintButton");

// Event listener for hint button
hintButton.addEventListener("click", function () {
    alert("Hint: The PIN is your birth year.");
});

// Event listener for form submission
pinForm.addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent the form from submitting

    const pinInput = document.getElementById("pin");
    const pinValue = pinInput.value.trim();

    // Check if the entered PIN is correct (e.g., "2003")
    if (pinValue === "2003") {
        // Redirect to the next page (index.html)
        window.location.href = "index.html";
    } else {
        alert("Wrong PIN! Try again.");
        pinInput.value = ""; // Clear the input field
    }
});
