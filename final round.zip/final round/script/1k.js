// Generate links for 100 text files
const fileList = document.getElementById("fileList");
const flagInput = document.getElementById("flag");
const submitButton = document.querySelector("#flagForm button");

for (let i = 1; i <= 100; i++) {
    const fileName = `file_${i}.txt`;
    const link = document.createElement("a");
    link.href = `files/${fileName}`;
    link.textContent = `Text File ${i}`;
    link.setAttribute("download", "");

    const listItem = document.createElement("li");
    listItem.appendChild(link);
    
    fileList.appendChild(listItem);
}

// Check the flag input for "adnan"
// Check the flag input for "adnan"
document.getElementById("flagForm").addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent the form from submitting

    const flagValue = flagInput.value.trim();
    if (flagValue === "flag{ITS_GETTING_MORE_HARD}") {
        alert("Flag is correct! You can now Set Sail!");
        // Redirect to index.html when the flag is correct
        window.location.href = "index.html";
    } else {
        alert("Wrong flag! You can't Set Sail yet!");
    }
});

